from flask import Flask, request, jsonify, render_template
import pickle
import pandas as pd
import numpy as np


# Load the trained model
with open("model.pkl", "rb") as file:
    model = pickle.load(file)

# Load the column names used during training
with open("columns.pkl", "rb") as file:
    columns = pickle.load(file)

#Load dataset to extract city names and cuisine names
df = pd.read_csv("display.csv")  # Ensure this is the correct dataset
unique_cities = sorted(df["City"].dropna().unique().tolist())  # Extract unique city names

# Extract cuisine names from one-hot encoded columns
cuisine_columns = [col for col in df.columns if df[col].nunique() == 2 and set(df[col].unique()) == {0, 1}]
unique_cuisines = sorted(cuisine_columns)  # Store cuisine names

app = Flask(__name__)

@app.route('/')
def home():
    return render_template("index.html", cities=unique_cities, cuisines=unique_cuisines)

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get user inputs
        city = request.form.get("city")
        cuisine = request.form.get("cuisine")
        cost = request.form.get("cost")
        menu = request.form.get("menu")
        delivery = request.form.get("delivery")
        varieties = request.form.get("varieties")
        bestsellers = request.form.get("bestsellers")

        # Validate inputs
        if not all([city, cuisine, cost, menu, delivery, varieties, bestsellers]):
            return jsonify({"error": "Missing input values"})

        cost = float(cost)
        varieties = float(varieties)
        bestsellers = float(bestsellers)
        menu = 1 if menu == "Yes" else 0
        delivery = 1 if delivery == "Yes" else 0

        # Create input DataFrame with zeros
        input_data = pd.DataFrame(np.zeros((1, len(columns))), columns=columns)

        # Set values based on input
        city_column = f"City_{city}"
        if city_column in columns:
            input_data[city_column] = 1

        if cuisine in columns:
            input_data[cuisine] = 1  # Set the selected cuisine to 1

        input_data["Cost_Per_Person"] = cost
        input_data["No_of_Varieties"] = varieties
        input_data["No_of_Best_Sellers"] = bestsellers
        input_data["Menu"] = menu
        input_data["Delivery"] = delivery

        # Make prediction
        prediction = model.predict(input_data)[0]

        return jsonify({"predicted_rating": round(prediction, 2)})

    except Exception as e:
        return jsonify({"error": "Prediction failed", "details": str(e)})

if __name__ == '__main__':
    app.run(debug=True)
